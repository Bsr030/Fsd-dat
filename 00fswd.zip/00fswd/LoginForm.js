import React,{useState} from "react";
const LoginForm=()=>{
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    const handleLogin=()=>{
        if(!username || !password)
        {
            setError("Invalid username or password,Retry again!");
        }

        if (username==='user' && password==='pass!123')
        {
            setIsLoggedIn(true);
            setError('')
        }
        else{
            setError("Invalid username or password");
        }
    }

    return(
        
        <div>
        {!isLoggedIn ? (
        <div>
        <h2>Login</h2>
        <div>
        <label>Username:</label>
        <input type="text" value={username} onChange={(e) => setUsername(e.target.value)}/>
        </div>
        <div>
        <label>Password:</label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
        />
        </div>
        <button onClick={handleLogin}>Login</button>
        {error && <p style={{ color: 'red' }}>{error}</p>}
        </div>
        ) : (
        <div>
        <h2>Welcome, {username}!</h2>
        </div>
        )}
        </div>
    );
}
export default LoginForm;