import React,{useState} from "react";

const Counter=()=>{

    const [count,setCount]=useState(0);

    // const handleChange=(num)=>{
    //     setCount(parseInt(num.target.value, 10) || 0);
    // }
    const handleIncrement=()=>{
        setCount((prevCount)=>prevCount+1);
    }
    const handleDecrement=()=>{
        setCount((prevCount)=>(prevCount>0 ? prevCount-1:0));
    }

    return(
        <><h1>Counter</h1>
        <input type="number" id='in_num' value={count} placeholder='Enter a number!'/>
        <p>Count: {count}</p>
        <button onClick={handleIncrement}>Increment</button> 
        <button onClick={handleDecrement}>Decrement</button>
        </>
    );
}

export default Counter;