// WordCounter.jsx
import React, { useState } from 'react';

const WordCounter = () => {
  const [text, setText] = useState('enter text here!');
  const handleChange = (event) => {
    setText(event.target.value);
  };

  return (
    <div>
        <h1>Word Counter</h1>
      <div className="m3">
        <textarea
          name="form-control"
          id="myBox"
          value={text}
          onChange={handleChange}
          cols="60"
          rows="10"
        ></textarea>
        <div className="container my-3">
          <h2>Text Summary</h2> 
          <br /> <br />
          <p>{text.split(' ').length} words and {text.length} characters</p>
        </div>
      </div>
    </div>
  );
};
export default WordCounter;

