import React, { useState } from "react";

const NumberToWordsConverter = (props) => {
  const [number, setNumber] = useState('');
  const [result, setResult] = useState('');

  const convertToWords = () => {
    // Implement your logic to convert the number to words here
    const convertedWords = numberToWords(number);
    setResult(convertedWords);
  };

  const handleOnChange = (event) => {
    setNumber(event.target.value);
  };

  const numberToWords = (num) => {
    // Implement your actual conversion logic here
    // This is a simple example and might not cover all cases
    const units = ['Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
    return units[num] || 'Number not supported';
  };

  return (
    <div>
      <h1>{props.heading}</h1>
      <div className="m3">
        <input type="number" value={number} onChange={handleOnChange} placeholder="Enter a number" />
        <button className="btn-primary" onClick={convertToWords}>Convert to Words</button>
        <p>{result && `Words: ${result}`}</p>
      </div>
    </div>
  );
};

export default NumberToWordsConverter;
