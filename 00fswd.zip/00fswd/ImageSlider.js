
import React ,{useState} from 'react';
const ImageSlider = ({ images }) => {
    const [currentIndex, setCurrentIndex] = useState(0);
  
    const goToNext = () => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
    };
  
    const goToPrevious = () => {
      setCurrentIndex((prevIndex) => (prevIndex - 1 + images.length) % images.length);
    };
  
    const goToIndex = (index) => {
      setCurrentIndex(index);
    };
  
    return (
      <div className="image-slider">
        <div className="image-container">
          <img src={images[currentIndex]} alt={`Image ${currentIndex}`} />
        </div>
        <div className="controls">
          <button onClick={goToPrevious}>Previous</button>
          <button onClick={goToNext}>Next</button>
        </div>
        <div className="option-circles">
          {images.map((image, index) => (
            <div
              key={index}
              className={`option-circle ${index === currentIndex ? 'active' : ''}`}
              onClick={() => goToIndex(index)}
            />
          ))}
        </div>
      </div>
    );
  };
export default ImageSlider;